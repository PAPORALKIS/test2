# papo-renov
# Lancer le globe en test
- dans la console faire cette ligne de commande = 
python -m http.server 8000
